# Build Vishal AI Hub APK from your phone

This project includes a GitHub Actions workflow that builds the Android debug APK in GitHub's hosted runner.

## Phone steps

1. Create a GitHub repository (public is simplest for free Actions usage).
2. Upload the **contents of this project** so `build.gradle.kts`, `settings.gradle.kts`, `app/`, and `.github/` are at the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build Vishal AI Hub APK**.
5. Tap **Run workflow**.
6. Wait for the build to finish.
7. Open the completed run and download the **VishalAIHub-debug-apk** artifact.

The workflow installs Gradle 8.10 automatically, so a Gradle wrapper is not required.

## Important

This is a debug APK for testing. It is not a Play Store release build and is not signed with a production release key.

The current app uses offline demo responses. A real AI backend/API still needs to be connected separately; never put a private API key directly into the APK source.

package com.vishal.aihub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

private val Bg = Color(0xFF0B0B12)
private val Card = Color(0xFF171522)
private val Purple = Color(0xFF8B5CF6)
private val Muted = Color(0xFFAAA6BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VishalAIHubApp() }
    }
}

@Composable
fun VishalAIHubApp() {
    val nav = rememberNavController()
    val scheme = darkColorScheme(
        background = Bg,
        surface = Card,
        primary = Purple,
        onPrimary = Color.White,
        onBackground = Color.White,
        onSurface = Color.White
    )
    MaterialTheme(colorScheme = scheme) {
        Scaffold(
            containerColor = Bg,
            bottomBar = { BottomBar(nav) }
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = "home",
                modifier = Modifier.padding(padding)
            ) {
                composable("home") { Home(nav) }
                composable("chat") { Chat() }
                composable("tools") { Tools() }
                composable("settings") { Settings() }
            }
        }
    }
}

@Composable
private fun BottomBar(nav: NavHostController) {
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val items = listOf(
        "home" to ("Home" to Icons.Default.Home),
        "chat" to ("Chat" to Icons.Default.Chat),
        "tools" to ("Tools" to Icons.Default.Build),
        "settings" to ("Settings" to Icons.Default.Settings)
    )
    NavigationBar(containerColor = Card) {
        items.forEach { (route, pair) ->
            NavigationBarItem(
                selected = current == route,
                onClick = { if (current != route) nav.navigate(route) },
                icon = { Icon(pair.second, contentDescription = pair.first) },
                label = { Text(pair.first) }
            )
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.padding(20.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) {
            Text(subtitle, color = Muted, modifier = Modifier.padding(top = 5.dp))
        }
    }
}

@Composable
private fun Home(nav: NavHostController) {
    LazyColumn(Modifier.fillMaxSize()) {
        item { Header("Vishal AI Hub 👋", "Your AI workspace, ready to explore.") }
        item {
            Text("Quick actions", color = Muted, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Feature("AI Chat", "Ask questions and get helpful responses", Icons.Default.Chat) { nav.navigate("chat") }
                Feature("AI Writer", "Draft essays, captions and messages", Icons.Default.Edit) { nav.navigate("tools") }
                Feature("Homework Helper", "Get step-by-step explanations", Icons.Default.School) { nav.navigate("tools") }
                Feature("AI Image", "Prepare prompts for an image provider", Icons.Default.Image) { nav.navigate("tools") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Offline demo mode", fontWeight = FontWeight.Bold)
                    Text(
                        "The app works without an API key. Connect your own AI backend later if you want live model responses.",
                        color = Muted,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun Feature(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Purple.copy(alpha = 0.2f), shape = RoundedCornerShape(14.dp)) {
                Icon(icon, contentDescription = title, tint = Purple, modifier = Modifier.padding(13.dp))
            }
            Column(Modifier.padding(start = 15.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(description, color = Muted, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
private fun Chat() {
    var input by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(false, "Hi! I’m Vishal AI. Try asking me a question.")
        )
    }

    Column(Modifier.fillMaxSize()) {
        Header("AI Chat", "Offline demo responses are enabled.")
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            reverseLayout = false
        ) {
            items(messages) { message ->
                ChatBubble(message)
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask anything…") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp)
            )
            IconButton(
                onClick = {
                    val question = input.trim()
                    if (question.isNotEmpty()) {
                        messages.add(ChatMessage(true, question))
                        messages.add(ChatMessage(false, DemoAI.reply(question)))
                        input = ""
                    }
                }
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = Purple)
            }
        }
    }
}

data class ChatMessage(val fromUser: Boolean, val text: String)

@Composable
private fun ChatBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Card(shape = RoundedCornerShape(16.dp)) {
            Text(message.text, Modifier.padding(14.dp))
        }
    }
}

@Composable
private fun Tools() {
    var selected by remember { mutableStateOf("writer") }
    Column(Modifier.fillMaxSize()) {
        Header("AI Tools", "Useful tools with no account required.")
        TabRow(selectedTabIndex = if (selected == "writer") 0 else 1) {
            Tab(selected == "writer", onClick = { selected = "writer" }, text = { Text("Writer") })
            Tab(selected == "homework", onClick = { selected = "homework" }, text = { Text("Homework") })
        }
        if (selected == "writer") WriterTool() else HomeworkTool()
    }
}

@Composable
private fun WriterTool() {
    var topic by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(topic, { topic = it }, Modifier.fillMaxWidth(), label = { Text("Topic") })
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { result = DemoAI.writer(topic) },
            enabled = topic.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Generate") }
        if (result.isNotBlank()) {
            Card(Modifier.fillMaxWidth().padding(top = 14.dp), shape = RoundedCornerShape(18.dp)) {
                Text(result, Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun HomeworkTool() {
    var question by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            question,
            { question = it },
            Modifier.fillMaxWidth().heightIn(min = 120.dp),
            label = { Text("Homework question") }
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = { result = DemoAI.homework(question) },
            enabled = question.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Explain step by step") }
        if (result.isNotBlank()) {
            Card(Modifier.fillMaxWidth().padding(top = 14.dp), shape = RoundedCornerShape(18.dp)) {
                Text(result, Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
private fun Settings() {
    LazyColumn(Modifier.fillMaxSize()) {
        item { Header("Settings", "Vishal AI Hub configuration") }
        item { Setting("Appearance", "Dark AI-style theme", Icons.Default.DarkMode) }
        item { Setting("AI connection", "No API key is embedded in this app", Icons.Default.Security) }
        item { Setting("Image generation", "Add a secure backend/provider later", Icons.Default.Image) }
        item { Setting("About", "Vishal AI Hub • Version 1.0", Icons.Default.Info) }
    }
}

@Composable
private fun Setting(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(description, color = Muted) },
        leadingContent = { Icon(icon, contentDescription = title, tint = Purple) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}

private object DemoAI {
    fun reply(question: String): String {
        val q = question.lowercase()
        return when {
            q.contains("hello") || q.contains("hi") -> "Hello! 👋 I’m Vishal AI. This is offline demo mode."
            q.contains("who are you") -> "I’m Vishal AI Hub, an Android AI assistant demo."
            q.contains("math") -> "I can help with maths. Send the full problem and I’ll break it into steps."
            else -> "I received: \"$question\"\n\nThis build is running in offline demo mode. To get live AI answers, connect a compatible AI backend without putting a secret API key directly in the APK."
        }
    }

    fun writer(topic: String): String =
        "Draft about $topic\n\nIntroduction: $topic is an interesting topic worth understanding.\n\nMain idea: Start with the key facts, explain them clearly, and add examples that make the subject easy to understand.\n\nConclusion: A clear summary helps the reader remember the most important points.\n\nDemo mode: connect an AI backend for fully generated writing."

    fun homework(question: String): String =
        "Step 1: Identify what the question is asking.\n\nStep 2: List the information or values given.\n\nStep 3: Choose the relevant rule or formula.\n\nStep 4: Work through the calculation carefully.\n\nQuestion received: $question\n\nThis is an offline helper template. Connect an AI backend for subject-specific solutions."
}

# Vishal AI Hub custom ProGuard/R8 rules.

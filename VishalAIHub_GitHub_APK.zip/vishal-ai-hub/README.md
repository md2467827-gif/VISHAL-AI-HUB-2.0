# Vishal AI Hub

A native Android/Jetpack Compose starter app for an AI hub.

## Current build
- Kotlin + Jetpack Compose
- compileSdk/targetSdk 35
- minSdk 26
- package `com.vishal.aihub`
- Home, Chat, Writer, Homework and Settings screens
- Offline demo responses so the app works without an API key
- No Firebase and no WebView

## Live AI
This build intentionally does not embed a secret AI API key. To add live AI, connect a secure backend/provider. Putting a private provider key directly into an APK is not secure.

## Build
Open the `vishal-ai-hub` folder in Android Studio, let Gradle sync, then use **Build > Build APK(s)**.
